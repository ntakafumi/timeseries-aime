# ts_aime/core.py
# Time-Series AIME (rolling AIME for time series) on top of aime-xai and pyEDM.
# Author: (your names)
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional, Tuple, Dict

import numpy as np
import pandas as pd

try:
    # public package you already released
    from aime_xai import AIME  # pip install aime-xai
except Exception as e:
    raise ImportError("aime-xai が必要です。`pip install aime-xai` を実行してください。") from e


def _zscore(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series, pd.Series]:
    mu = df.mean()
    sd = df.std(ddof=0).replace(0, 1.0)
    return (df - mu) / sd, mu, sd


@dataclass
class RollingAIMEConfig:
    window: int = 90        # time window length
    tp:     int = 1         # prediction horizon (EDM Tp)
    preserve_weekly: bool = False  # permutation: shift by multiple of 7
    R:      int = 0         # permutations (0: skip envelope/p-values)
    seed:   int = 0
    ridge:  float = 1e-12   # numerical stabilization for denom
    pre_normalize_y: bool = False  # usually False: aime-xai側のnormalize=Trueに委ねる


class RollingAIME:
    """
    Rolling AIME on top of pyEDM (S-Map) + aime-xai.

    - 予測モデル: pyEDM.SMap を窓内で学習し、Time(t) -> yhat(t+Tp)
    - 整列: 特徴 X(t) と 予測 yhat(t+Tp) を Time で厳密に inner join
    - AIME: aime-xai の A_dagger を窓ごとに作成（normalize=True）
    - 出力: global_ts（各窓のグローバルAIME）, local_ts（窓末尾のローカルAIME）
            perm_envelope（95%帯）, pvals（二側・円周シフト）

    参考: AIME 本体の定義は Sec.III-B/E, Fig.2。A† = X Y^T (Y Y^T)^{-1}。 [oai_citation:1‡Approximate_Inverse_Model_Explanations_AIME_Unveiling_Local_and_Global_Insights_in_Machine_Learning_Models (8).pdf](file-service://file-3pLPafHrDkvQZCdyEPCKNg)
    """
    def __init__(self, cfg: RollingAIMEConfig):
        self.cfg = cfg
        self.last_A_dagger_: Optional[np.ndarray] = None  # (p,1) of last window

    # ---------- pyEDM で学習・予測（窓内） ----------
    @staticmethod
    def _fit_smap_and_predict(sub: pd.DataFrame,
                              feats: List[str],
                              target: str,
                              E: int,
                              theta: float,
                              embedded: bool,
                              tp: int) -> pd.DataFrame:
        try:
            import pyEDM as ed
        except Exception as e:
            raise ImportError("pyEDM が必要です。`pip install pyEDM==1.14.0.2` 等を実行してください。") from e

        cols_str = " ".join(feats)
        sm = ed.SMap(
            dataFrame=sub[["Time"] + feats],
            columns=cols_str, target=target,
            lib=f"1 {len(sub)}", pred=f"1 {len(sub)}",
            E=(len(feats) if embedded else E),
            embedded=embedded, theta=theta, Tp=tp, showPlot=False
        )
        pred = sm["predictions"][["Time", "Observations", "Predictions"]].copy()
        return pred  # Time is t+tp

    # ---------- 整列: X(t) と yhat(t+tp) を一致 ----------
    @staticmethod
    def _align_xy_for_aime(sub: pd.DataFrame, pred: pd.DataFrame,
                           feats: List[str], tp: int) -> Tuple[pd.DataFrame, np.ndarray, pd.Series, pd.Series]:
        Xw = sub[["Time"] + feats].copy()
        Xw["Time_pred"] = Xw["Time"] + tp  # t -> t+tp
        P = pred[["Time", "Predictions"]].rename(columns={"Time": "Time_pred"})
        merged = Xw.merge(P, on="Time_pred", how="inner", validate="one_to_one")

        X_al = merged[feats].copy()
        yhat = merged["Predictions"].to_numpy().astype(float)
        Xz, _, _ = _zscore(X_al)

        t_pred = merged["Time_pred"]  # t+tp
        t_src  = merged["Time"]       # t
        return Xz, yhat, t_pred, t_src

    # ---------- 1窓 AIME（aime-xai で A† を取得） ----------
    def _aime_from_window(self, Xz: pd.DataFrame, yhat: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        returns:
          A_dagger: (p,1)
          gi:       (p,)  global importance (flatten)
          l_last:   (p,)  local importance at the last row (Hadamard)
        """
        Xn = np.asarray(Xz, dtype=float)
        y  = np.asarray(yhat, dtype=float).reshape(-1, 1)

        # 任意で事前に y を標準化（通常は aime-xai 側の normalize=True に委ねる）
        if self.cfg.pre_normalize_y:
            mu = y.mean()
            sd = y.std(ddof=0) if y.std(ddof=0) > 0 else 1.0
            y = (y - mu) / sd

        expl = AIME()
        # AIME 側で normalize=True → X, y を正規化して A† を計算（AIMEの前提） [oai_citation:2‡Approximate_Inverse_Model_Explanations_AIME_Unveiling_Local_and_Global_Insights_in_Machine_Learning_Models (8).pdf](file-service://file-3pLPafHrDkvQZCdyEPCKNg)
        expl.create_explainer(Xn, y, normalize=True)
        A_dagger = np.asarray(expl.A_dagger, dtype=float)  # (p,1)
        self.last_A_dagger_ = A_dagger

        gi = A_dagger.flatten()  # global
        # local（回帰1出力の l_i = (A† * yhat_i) ◦ x_i）
        l_series = (y * A_dagger.T) * Xn  # (n,p)
        l_last   = l_series[-1, :]

        return A_dagger, gi, l_last

    # ---------- 置換（円周シフト）で帰無帯と p 値 ----------
    def _perm_envelope_and_p(self, Xz: pd.DataFrame, yhat: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        1窓分の 95%帯と p 値（二側）。X は正規化済み（DataFrame）、yhat は 1D。
        A† は AIME を毎回呼ばず、定義式（A†=X^T y / y^T y）で高速算出。 [oai_citation:3‡Approximate_Inverse_Model_Explanations_AIME_Unveiling_Local_and_Global_Insights_in_Machine_Learning_Models (8).pdf](file-service://file-3pLPafHrDkvQZCdyEPCKNg)
        returns: lo(p,), hi(p,), pvals(p,)
        """
        if self.cfg.R <= 0:
            return np.array([]), np.array([]), np.array([])

        rng = np.random.default_rng(self.cfg.seed)
        Xn  = np.asarray(Xz, dtype=float)
        y   = np.asarray(yhat, dtype=float).ravel()

        # z-score（窓内）して固定
        mu = y.mean(); sd = y.std(ddof=0); y = (y - mu) / (sd if sd > 0 else 1.0)
        n, p = Xn.shape
        gi_perm = np.zeros((self.cfg.R, p))

        for r in range(self.cfg.R):
            if self.cfg.preserve_weekly:
                kmax = max(1, n // 7)
                shift = 7 * rng.integers(1, kmax + 1)
            else:
                shift = rng.integers(1, n)
            y_perm = np.roll(y, shift)
            denom  = float(np.dot(y_perm, y_perm)) + self.cfg.ridge
            A_dag_p = (Xn.T @ y_perm.reshape(-1, 1)) / denom  # (p,1)
            gi_perm[r, :] = A_dag_p.flatten()

        lo = np.quantile(gi_perm, 0.025, axis=0)
        hi = np.quantile(gi_perm, 0.975, axis=0)
        # add-one 補正付き二側 p 値
        # 0 や 1 を避けるため (count+1)/(R+1)
        count = np.sum(np.abs(gi_perm) >= np.abs(gi_perm.mean(axis=0, keepdims=True)), axis=0)  # 近似
        pvals = (count + 1.0) / (self.cfg.R + 1.0)
        return lo, hi, pvals

    # ---------- 外部API：pyEDMで rolling ----------
    def fit_with_pyEDM(self,
                       df: pd.DataFrame,
                       columns: List[str],
                       target: str,
                       E: int,
                       theta: float,
                       embedded: bool = True) -> Tuple[pd.DataFrame, pd.DataFrame, Optional[pd.DataFrame], Optional[pd.DataFrame], Optional[pd.DataFrame]]:
        """
        df: 必須列 = ['Time'] + features（Time は 1..N の整数）
        returns:
          global_ts: Time, each feature column（グローバル AIME）
          local_ts:  Time, each feature column（窓末尾のローカル AIME）
          env_lo:    Time, features（95%帯 下）
          env_hi:    Time, features（95%帯 上）
          pvals:     Time, features（二側p）
        """
        feats = list(columns)
        win   = self.cfg.window
        tp    = self.cfg.tp

        G_rows: List[Dict] = []
        L_rows: List[Dict] = []
        ENV_LO: List[Dict] = []
        ENV_HI: List[Dict] = []
        PV:     List[Dict] = []

        for end in range(win, len(df) + 1):
            sub = df.iloc[end - win:end].copy()

            # 1) 窓内 S-Map → 予測（Time は t+tp）
            pred = self._fit_smap_and_predict(sub, feats, target, E=E, theta=theta, embedded=embedded, tp=tp)
            # 2) 整列（X(t) と yhat(t+tp)）
            Xz, yhat, t_pred, _ = self._align_xy_for_aime(sub, pred, feats, tp=tp)
            if len(yhat) == 0:
                continue

            # 3) AIME（aime-xai で A†）
            A_dag, gi, l_last = self._aime_from_window(Xz, yhat)
            t_end_pred = int(t_pred.iloc[-1])

            G_rows.append(dict(Time=t_end_pred, **{f: v for f, v in zip(feats, gi)}))
            L_rows.append(dict(Time=t_end_pred, **{f: l_last[j] for j, f in enumerate(feats)}))

            # 4)（任意）置換帯と p 値
            if self.cfg.R > 0:
                lo, hi, p = self._perm_envelope_and_p(Xz, yhat)
                ENV_LO.append(dict(Time=t_end_pred, **{f: lo[j] for j, f in enumerate(feats)}))
                ENV_HI.append(dict(Time=t_end_pred, **{f: hi[j] for j, f in enumerate(feats)}))
                PV.append(    dict(Time=t_end_pred, **{f: p[j]  for j, f in enumerate(feats)}))

        global_ts = pd.DataFrame(G_rows)
        local_ts  = pd.DataFrame(L_rows)
        env_lo = pd.DataFrame(ENV_LO) if ENV_LO else None
        env_hi = pd.DataFrame(ENV_HI) if ENV_HI else None
        pvals  = pd.DataFrame(PV)     if PV     else None
        return global_ts, local_ts, env_lo, env_hi, pvals