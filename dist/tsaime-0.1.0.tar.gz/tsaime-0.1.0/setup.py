# setup.py
from setuptools import setup, find_packages

setup(
    name="tsaime",
    version="0.1.0",
    description="Time-Series AIME: Rolling AIME on top of aime-xai and pyEDM",
    author="Your Team",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21",
        "pandas>=1.3",
        "aime-xai>=0.1.0",   # あなたの公開版に合わせて調整
        "pyEDM>=1.14.0.2"
    ],
    license="Apply the The 2-Clause BSD License only for academic or research purposes, and apply Commercial License for commercial and other purposes.",
)